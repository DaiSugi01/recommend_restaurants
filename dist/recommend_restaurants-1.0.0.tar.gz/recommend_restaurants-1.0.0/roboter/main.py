from roboter.controller import conversation

conversation.talk_about_restaurant()