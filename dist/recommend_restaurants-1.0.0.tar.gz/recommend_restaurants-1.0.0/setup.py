from setuptools import setup

setup(
    name='recommend_restaurants',
    version='1.0.0',
    packages=['roboter', 'roboter.view', 'roboter.models', 'roboter.controller'],
    url='',
    license='Free',
    author='sugiharadaiki',
    author_email='',
    description='recommend_restaurants package'
)
